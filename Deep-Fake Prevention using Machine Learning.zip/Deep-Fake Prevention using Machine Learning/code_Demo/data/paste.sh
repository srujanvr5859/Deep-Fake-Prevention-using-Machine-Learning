#!/bin/bash

# Check if the Hollywood2-actions.tar.gz file exists
if [ -f "Hollywood2-actions.tar.gz" ]; then
    echo "Extracting Hollywood2-actions.tar.gz..."
    tar -zxvf Hollywood2-actions.tar.gz

    # echo "Removing the tar.gz file..."
    # rm Hollywood2-actions.tar.gz

    echo "Renaming directory from 'Hollywood2' to 'hollywood2'..."
    mv Hollywood2 hollywood2

    echo "Creating train and val directories..."
    mkdir -p hollywood2/train
    mkdir -p hollywood2/val

    echo "Moving training files to 'train' directory..."
    mv hollywood2/AVIClips/*train*.avi hollywood2/train/

    echo "Moving validation files to 'val' directory..."
    mv hollywood2/AVIClips/*test*.avi hollywood2/val/

    echo "Setup completed successfully!"
else
    echo "Error: Hollywood2-actions.tar.gz not found in the current directory."
    echo "Please ensure the file has been downloaded before running this script."
fi
